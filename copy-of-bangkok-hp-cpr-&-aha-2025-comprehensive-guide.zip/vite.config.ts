import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  // 針對 GitHub Pages 部署，必須設定為倉庫名稱
  base: '/2025HPCPR/',
  build: {
    outDir: 'dist',
    emptyOutDir: true
  }
});